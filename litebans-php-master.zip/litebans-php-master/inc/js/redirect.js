var url = document.getElementById("redirect-url");
if (url !== null) {
    document.location = url.value;
}